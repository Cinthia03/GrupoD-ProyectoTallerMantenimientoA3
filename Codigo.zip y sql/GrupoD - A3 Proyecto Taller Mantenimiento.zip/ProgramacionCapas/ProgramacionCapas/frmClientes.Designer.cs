﻿namespace CapaPresentacion
{
    partial class frmClientes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button1 = new Button();
            textBox1 = new TextBox();
            dgvCargaClientes = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)dgvCargaClientes).BeginInit();
            SuspendLayout();
            // 
            // button1
            // 
            button1.Location = new Point(40, 41);
            button1.Name = "button1";
            button1.Size = new Size(109, 23);
            button1.TabIndex = 0;
            button1.Text = "Buscar cliente";
            button1.UseVisualStyleBackColor = true;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(176, 41);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(349, 23);
            textBox1.TabIndex = 1;
            // 
            // dgvCargaClientes
            // 
            dgvCargaClientes.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvCargaClientes.Location = new Point(40, 86);
            dgvCargaClientes.Name = "dgvCargaClientes";
            dgvCargaClientes.RowTemplate.Height = 25;
            dgvCargaClientes.Size = new Size(699, 338);
            dgvCargaClientes.TabIndex = 2;
            dgvCargaClientes.CellDoubleClick += dataGridView1_CellDoubleClick;
            // 
            // frmClientes
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(dgvCargaClientes);
            Controls.Add(textBox1);
            Controls.Add(button1);
            Name = "frmClientes";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "frmClientes";
            ((System.ComponentModel.ISupportInitialize)dgvCargaClientes).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button1;
        private TextBox textBox1;
        private DataGridView dgvCargaClientes;
    }
}